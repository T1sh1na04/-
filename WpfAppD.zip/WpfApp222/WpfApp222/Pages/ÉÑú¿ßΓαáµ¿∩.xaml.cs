﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp222.Pages;

namespace WpfApp222.Pages
{
    /// <summary>
    /// Логика взаимодействия для LogPage.xaml
    /// </summary>
    public partial class LogPage : Page
    {
        private User _currentUser = new User();
        public LogPage()
        {
            InitializeComponent();
            Role_tb.ItemsSource = App.Context.Role.ToList();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentUser.ID_USER == 0)
            {
                App.Context.User.Add(_currentUser);
                try
                {
                    App.Context.SaveChanges();
                    MessageBox.Show("Пользователь добавлен");
                }
                catch
                {
                    MessageBox.Show("Ошибка");
                }
                this.NavigationService.Navigate(new MainMenu());
            }
        }
        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.GoBack();
        }
    }
}
